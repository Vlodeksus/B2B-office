<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="format-detection" content="telephone=no" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />
<meta name='robots' content='noindex,nofollow' />
<link href="css/main.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="img/favicon.ico" />