<link href="css/bootstrap-grid.min.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="assets/bootstrap-icons/bootstrap-icons.css" rel="stylesheet" type="text/css">


<script src="js/jquery.min.js"></script>
<script defer src="js/SmoothScroll.js"></script>
<script defer src="js/global.js"></script>